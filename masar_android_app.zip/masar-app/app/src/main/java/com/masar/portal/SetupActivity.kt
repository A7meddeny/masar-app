package com.masar.portal

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.masar.portal.databinding.ActivitySetupBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

class SetupActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySetupBinding
    private val app get() = application as MasarApp

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // إذا الرابط مضبوط من قبل، انتقل مباشرة للشاشة الرئيسية
        val existing = app.prefs.getString(MasarApp.KEY_BASE_URL, null)
        if (!existing.isNullOrBlank()) {
            startMain()
            return
        }

        binding = ActivitySetupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.continueBtn.setOnClickListener { onContinue() }
    }

    private fun onContinue() {
        var url = binding.urlInput.text.toString().trim()
            .removeSuffix("/")
            .removePrefix("http://").removePrefix("https://")
            .removePrefix("www.")
        if (url.isEmpty() || !url.contains(".")) {
            showError(getString(R.string.setup_invalid))
            return
        }
        val finalUrl = "https://$url"
        binding.progress.visibility = View.VISIBLE
        binding.errorText.visibility = View.GONE
        binding.continueBtn.isEnabled = false

        lifecycleScope.launch {
            val ok = checkUrlReachable(finalUrl)
            binding.progress.visibility = View.GONE
            binding.continueBtn.isEnabled = true
            if (ok) {
                app.prefs.edit().putString(MasarApp.KEY_BASE_URL, finalUrl).apply()
                startMain()
            } else {
                showError(getString(R.string.setup_unreachable))
            }
        }
    }

    private suspend fun checkUrlReachable(url: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val conn = (URL("$url/portal.php").openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 8000
                requestMethod = "GET"
                instanceFollowRedirects = true
            }
            val code = conn.responseCode
            conn.disconnect()
            code in 200..399
        } catch (e: Exception) {
            false
        }
    }

    private fun showError(msg: String) {
        binding.errorText.text = msg
        binding.errorText.visibility = View.VISIBLE
    }

    private fun startMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
