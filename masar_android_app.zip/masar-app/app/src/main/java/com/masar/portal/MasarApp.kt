package com.masar.portal

import android.app.Application
import android.content.Context
import android.content.SharedPreferences

class MasarApp : Application() {
    companion object {
        const val PREFS = "masar_prefs"
        const val KEY_BASE_URL = "base_url"
    }

    val prefs: SharedPreferences by lazy {
        getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    }
}
