package com.masar.portal

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.webkit.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.masar.portal.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val app get() = application as MasarApp
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null

    // مختار الملفات للحوادث/البنزين
    private val fileLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val uris: Array<Uri>? = if (result.resultCode == Activity.RESULT_OK) {
            val data = result.data
            when {
                data?.dataString != null -> arrayOf(Uri.parse(data.dataString))
                data?.clipData != null -> {
                    val clip = data.clipData!!
                    Array(clip.itemCount) { clip.getItemAt(it).uri }
                }
                else -> null
            }
        } else null
        fileChooserCallback?.onReceiveValue(uris)
        fileChooserCallback = null
    }

    private val cameraPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* allow proceed regardless */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val baseUrl = app.prefs.getString(MasarApp.KEY_BASE_URL, null)
        if (baseUrl.isNullOrBlank()) {
            startActivity(Intent(this, SetupActivity::class.java))
            finish()
            return
        }

        setupWebView()
        binding.swipe.setColorSchemeResources(R.color.brand_red)
        binding.swipe.setOnRefreshListener {
            binding.webView.reload()
        }
        binding.retryBtn.setOnClickListener {
            binding.errorOverlay.visibility = View.GONE
            binding.webView.reload()
        }
        binding.changeUrlBtn.setOnClickListener { askChangeUrl() }

        binding.webView.loadUrl("$baseUrl/portal.php")

        // اطلب صلاحية الكاميرا لرفع صور الحوادث
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            cameraPermLauncher.launch(Manifest.permission.CAMERA)
        }

        // التحكم بزر الرجوع — يرجع لصفحة سابقة في WebView بدلاً من الخروج
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (binding.webView.canGoBack()) binding.webView.goBack()
                else confirmExit()
            }
        })
    }

    @Suppress("SetJavaScriptEnabled")
    private fun setupWebView() {
        val w = binding.webView
        w.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(false)
            mediaPlaybackRequiresUserGesture = false
            cacheMode = WebSettings.LOAD_DEFAULT
            useWideViewPort = true
            loadWithOverviewMode = true
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            userAgentString = "$userAgentString MasarApp/1.0"
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)

        w.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                binding.loadingOverlay.visibility = View.GONE
                binding.swipe.isRefreshing = false
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                if (request?.isForMainFrame == true) {
                    binding.errorOverlay.visibility = View.VISIBLE
                    binding.loadingOverlay.visibility = View.GONE
                }
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                val base = app.prefs.getString(MasarApp.KEY_BASE_URL, "") ?: ""
                // اسمح بالملاحة داخل نطاقنا فقط، الباقي يفتح بمتصفح خارجي
                return if (url.startsWith(base) || url.contains("vr2.umniate.com")) {
                    false
                } else {
                    try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) {}
                    true
                }
            }
        }

        w.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileChooserCallback?.onReceiveValue(null)
                fileChooserCallback = filePathCallback
                val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                try { fileLauncher.launch(intent); return true }
                catch (e: Exception) { fileChooserCallback = null; return false }
            }

            override fun onPermissionRequest(request: PermissionRequest?) {
                runOnUiThread { request?.grant(request.resources) }
            }
        }
    }

    private fun askChangeUrl() {
        AlertDialog.Builder(this)
            .setTitle(R.string.setup_change)
            .setMessage("ستعود لشاشة الإعداد. هل تريد المتابعة؟")
            .setPositiveButton("نعم") { _, _ ->
                app.prefs.edit().remove(MasarApp.KEY_BASE_URL).apply()
                startActivity(Intent(this, SetupActivity::class.java))
                finish()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun confirmExit() {
        AlertDialog.Builder(this)
            .setMessage("إغلاق التطبيق؟")
            .setPositiveButton("نعم") { _, _ -> finish() }
            .setNegativeButton("لا", null)
            .show()
    }
}
